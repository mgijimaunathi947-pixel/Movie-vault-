# MovieVault

Android movie-downloader starter app with a dark cinematic interface, search, offline download button, and Android Download Manager integration.

## Content policy
The app is designed to use movies that are public-domain or distributed under licenses permitting downloading. The demo catalogue uses example Internet Archive-hosted files; verify each item's current license before distribution.

## Build
Open this folder in Android Studio and build the `app` module. The project targets Android 8.0+ (API 26) and Android 15 (API 35).

## Important
This project intentionally does not scrape or provide unauthorized copyrighted movies, torrent sources, DRM bypasses, or piracy indexes.
