package com.movievault.app;

import android.app.*;import android.os.*;import android.content.*;import android.graphics.Color;import android.net.Uri;import android.view.*;import android.widget.*;import java.util.*;

public class MainActivity extends Activity {
  LinearLayout root, content; EditText search; final ArrayList<Movie> movies=new ArrayList<>();
  int gold=Color.rgb(215,179,90), bg=Color.rgb(16,16,16), card=Color.rgb(25,25,25);
  @Override public void onCreate(Bundle b){super.onCreate(b); seed(); build(); showHome();}
  void seed(){
    movies.add(new Movie("Big Buck Bunny","2008","Animation • Comedy","https://archive.org/download/BigBuckBunny_328/BigBuckBunny_512kb.mp4"));
    movies.add(new Movie("Sintel","2010","Fantasy • Animation","https://archive.org/download/Sintel/sintel-2048-surround.mp4"));
    movies.add(new Movie("Tears of Steel","2012","Sci-Fi • Drama","https://archive.org/download/TearsOfSteel1080p/TearsOfSteel.mp4"));
  }
  TextView tv(String s,int sp){TextView t=new TextView(this);t.setText(s);t.setTextColor(Color.WHITE);t.setTextSize(sp);t.setPadding(18,10,18,10);return t;}
  void build(){
    root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(bg);
    LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);bar.setPadding(10,12,10,6);
    TextView logo=tv("MOVIEVAULT",22);logo.setTextColor(gold);logo.setTypeface(null,1);bar.addView(logo,new LinearLayout.LayoutParams(0,60,1));
    Button dl=new Button(this);dl.setText("Downloads");dl.setTextColor(Color.WHITE);dl.setBackgroundColor(Color.TRANSPARENT);dl.setOnClickListener(v->showDownloads());bar.addView(dl,new LinearLayout.LayoutParams(-2,60));root.addView(bar);
    search=new EditText(this);search.setHint("Search movies");search.setHintTextColor(Color.GRAY);search.setTextColor(Color.WHITE);search.setSingleLine();search.setPadding(18,0,18,0);root.addView(search,new LinearLayout.LayoutParams(-1,58));
    search.setOnEditorActionListener((v,a,e)->{showHome();return false;});
    ScrollView sv=new ScrollView(this);content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(12,12,12,90);sv.addView(content);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);
  }
  void showHome(){content.removeAllViews();content.addView(tv("FREE & LEGALLY DOWNLOADABLE",14));String q=search.getText().toString().toLowerCase();for(Movie m:movies)if(q.isEmpty()||m.title.toLowerCase().contains(q)){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(14,14,14,14);c.setBackgroundColor(card);TextView title=tv(m.title,20);title.setTextColor(gold);c.addView(title);c.addView(tv(m.year+"  •  "+m.genre,13));Button b=new Button(this);b.setText("DOWNLOAD FOR OFFLINE");b.setOnClickListener(v->download(m));c.addView(b);content.addView(c,new LinearLayout.LayoutParams(-1,180));Space s=new Space(this);content.addView(s,new LinearLayout.LayoutParams(1,10));}}
  void download(Movie m){android.app.DownloadManager dm=(android.app.DownloadManager)getSystemService(DOWNLOAD_SERVICE);DownloadManager.Request r=new DownloadManager.Request(Uri.parse(m.url));r.setTitle(m.title);r.setDescription("MovieVault offline download");r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);r.setAllowedOverMetered(true);r.setAllowedOverRoaming(false);dm.enqueue(r);Toast.makeText(this,"Download started: "+m.title,Toast.LENGTH_LONG).show();}
  void showDownloads(){content.removeAllViews();content.addView(tv("YOUR DOWNLOADS",20));content.addView(tv("Downloads are handled by Android's Download Manager and appear in your device's Downloads list.",14));Button h=new Button(this);h.setText("BACK TO MOVIES");h.setOnClickListener(v->showHome());content.addView(h);}
  static class Movie{String title,year,genre,url;Movie(String a,String b,String c,String d){title=a;year=b;genre=c;url=d;}}
}
